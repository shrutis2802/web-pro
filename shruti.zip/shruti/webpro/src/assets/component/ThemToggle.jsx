import React, { Fragment } from "react";

function ThemToggle({ theme, toggleTheme }) {
  return (
    <Fragment>
      <button
        style={{
          position: "fixed",
          bottom: "25px",
          right: "25px",
          width: "50px",
          height: "50px",
          borderRadius: "40%",
          border: "none",
          backgroundColor: theme === "light" ? "#222" : "#fff",
          color: theme === "light" ? "#fff" : "#222",
          cursor: "pointer",
        }}
        onClick={toggleTheme}
      >
        {theme === "light" ? "⭐" : "🌙"}
      </button>
    </Fragment>
  );
}

export default ThemToggle;
