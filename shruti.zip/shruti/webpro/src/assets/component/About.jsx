import React from "react";

const About = ({ theme }) => {
  return (
    <div>
      <h3>jhgyu</h3>
    </div>
  );
};

export default About;
