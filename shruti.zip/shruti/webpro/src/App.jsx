import { useEffect, useState } from "react";

import "./App.css";
import ThemToggle from "./assets/component/Themtoggle";
import Header from "./assets/component/Header";
import About from "./assets/component/About";
import Counter from "./assets/component/Counter";

const styles = {
  light: {
    bg: "#ffffff",
    text: "#333333",
    card: "#f5f5f5",
    border: "#ddd",
  },
  dark: {
    bg: "#222222",
    text: "#f5f5f5",
    card: "#333333",
    border: "#444",
  },
};
function App() {
  const [theme, setTheme] = useState("light");
  const [activeTab, setActiveTab] = useState("home");

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
  };

  // dependency => theme
  useEffect(() => {
    document.body.style.backgroundColor = styles[theme].bg;
    document.body.style.color = styles[theme].text;
  }, [theme]);

  const containerStyle = {
    minWidth: "1000px",
  };

  const mainStyle = {
    backgroundColor: styles[theme].card,
  };

  const footerStyle = {
    textAlign: "center",
    marginTop: "40px",
    fontSize: "14px",
  };

  return (
    <div style={containerStyle}>
      <Header />
      <main style={mainStyle}>
        {activeTab === "home" && (
          <div style={{ textAlign: "center" }}>hgufhduighifudh</div>
        )}

        {activeTab === "counter" && <Counter theme={theme} />}
        {activeTab === "About" && <About theme={theme} />}
      </main>
      <ThemToggle theme={"them"} toggleTheme={toggleTheme} />
    </div>
  );
}

//
// }

export default App;
